from flask import Flask, render_template, request
import pandas as pd
from itertools import combinations
import random
app = Flask(__name__)
@app.route('/', methods=['GET', 'POST'])
def find_best_team():
    if request.method == 'POST':
        characters_df = pd.read_csv('cartoon_characters.csv')
        enemy_df = pd.read_csv('enemy_dataset.csv')
        num_characters_to_select = 4
        characters_list = characters_df.to_dict('records')
        random.shuffle(characters_list)
        combinations_list = list(combinations(characters_list[:num_characters_to_select], num_characters_to_select))
        team_combinations = []

        for combination in combinations_list:
            team = list(combination)
            total_strength = sum(character['Strength'] for character in team)
            total_special_ability = sum(character['Special_Ability_Value'] for character in team)
            team_combinations.append((team, total_strength, total_special_ability))
        best_team = None
        best_score = float('-inf')

        for team, strength, special_ability in team_combinations:
            enemy_strength = enemy_df.iloc[0]['Strength']
            enemy_special_ability = enemy_df.iloc[0]['Special_Ability_Value']
            team_score = (strength - enemy_strength) + (special_ability - enemy_special_ability)

            if team_score > best_score:
                best_team = team
                best_score = team_score
        best_team_data = []
        for character in best_team:
            character_data = {
                'Character': character['Character'],
                'Strength': character['Strength'],
                'Special_Ability_Value': character['Special_Ability_Value']
            }
            best_team_data.append(character_data)
        total_team_score = best_score
        return render_template('result.html', best_team=best_team_data, total_team_score=total_team_score)
    return render_template('index.html')
if __name__ == '__main__':
    app.run(debug=True)
